import { test, expect } from '@playwright/test';
import type { Page, TestInfo } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
interface Audit { observers: Set<object>; resize: Set<unknown>; density: Set<unknown>; frames: Set<number> }
interface Diagnostics { applications: number; resources: number; subscriptions: number; cache: { leases: number; textures: number; pending: boolean; closed: boolean } }
declare global { interface Window { __arenaAudit: Audit; __arenaDiagnostics(): Diagnostics } }
const evidence = 'project/automation-reports/02-integrate-assets-and-arena-renderer/browser-evidence';
async function screenshot(page: Page, info: TestInfo, label: string) {
  await mkdir(evidence,{recursive:true});
  const file=path.resolve(evidence,`${info.project.name}-${label}.png`);
  await page.screenshot({path:file,fullPage:true});await info.attach(label,{path:file,contentType:'image/png'});
}
async function counts(page: Page) {
  return page.evaluate(()=>({ ...window.__arenaDiagnostics(), canvases:document.querySelectorAll('canvas').length, observers:window.__arenaAudit.observers.size, resize:window.__arenaAudit.resize.size, density:window.__arenaAudit.density.size, frames:window.__arenaAudit.frames.size }));
}
async function settled(page: Page) { await expect.poll(async()=> (await counts(page)).frames).toBe(0); }
async function arena(page: Page) {
  await expect(page.getByRole('heading',{name:'Static Arena',exact:true})).toBeVisible();
  await expect(page.getByRole('status')).toContainText('Static arena preview · No match is running');
  await expect(page.locator('canvas')).toHaveCount(1);await settled(page);
}
async function menu(page: Page) {
  await page.getByRole('button',{name:'Main Menu',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Pirate Battle'})).toBeVisible();
  await expect(page.locator('canvas')).toHaveCount(0);
  await expect.poll(async()=> (await counts(page)).applications).toBe(0);
}
test.beforeEach(async({page})=>{
  await page.addInitScript(()=>{
    const audit:Audit={observers:new Set(),resize:new Set(),density:new Set(),frames:new Set()};window.__arenaAudit=audit;
    const Observer=window.ResizeObserver;
    window.ResizeObserver=class extends Observer { observe(...args:Parameters<ResizeObserver['observe']>){audit.observers.add(this);return super.observe(...args);}disconnect(){audit.observers.delete(this);return super.disconnect();} };
    const add=window.addEventListener.bind(window),remove=window.removeEventListener.bind(window);
    window.addEventListener=((type: string,listener: EventListenerOrEventListenerObject,options?: boolean | AddEventListenerOptions)=>{if(type==='resize')audit.resize.add(listener);return add(type,listener,options);}) as typeof window.addEventListener;
    window.removeEventListener=((type: string,listener: EventListenerOrEventListenerObject,options?: boolean | AddEventListenerOptions)=>{if(type==='resize')audit.resize.delete(listener);return remove(type,listener,options);}) as typeof window.removeEventListener;
    const match=window.matchMedia.bind(window);
    window.matchMedia=query=>{const result=match(query),a=result.addEventListener.bind(result),r=result.removeEventListener.bind(result);
      result.addEventListener=((type: string,listener: EventListenerOrEventListenerObject,options?: boolean | AddEventListenerOptions)=>{if(type==='change')audit.density.add(listener);return a(type,listener,options);}) as typeof result.addEventListener;
      result.removeEventListener=((type: string,listener: EventListenerOrEventListenerObject,options?: boolean | AddEventListenerOptions)=>{if(type==='change')audit.density.delete(listener);return r(type,listener,options);}) as typeof result.removeEventListener;
      return result;
    };
    const request=window.requestAnimationFrame.bind(window),cancel=window.cancelAnimationFrame.bind(window);
    window.requestAnimationFrame=callback=>{const id=request(time=>{audit.frames.delete(id);callback(time);});audit.frames.add(id);return id;};
    window.cancelAnimationFrame=id=>{audit.frames.delete(id);cancel(id);};
  });
  const issues:string[]=[];
  page.on('pageerror',e=>issues.push(`pageerror: ${e.message}`));
  page.on('console',m=>{if(m.type()==='error')issues.push(`console: ${m.text()}`);});
  // Expected request failures are asserted in their dedicated test; JS exceptions are never ignored.
  (page as Page & {auditIssues:string[]}).auditIssues=issues;
});
test.afterEach(async({page},info)=>{
  const issues=(page as Page & {auditIssues:string[]}).auditIssues;
  await info.attach('console-issues',{body:JSON.stringify(issues,null,2),contentType:'application/json'});
  expect(issues).toEqual([]);
});

test('keyboard menu/loading/arena/menu and five Strict Mode cycles reuse textures',async({page},info)=>{
  await page.goto('/');await expect(page.getByRole('heading',{name:'Pirate Battle'})).toBeVisible();
  await screenshot(page,info,'menu-desktop');const initial=await counts(page);const cycles=[];
  for(let cycle=1;cycle<=5;cycle++) {
    const start=Date.now();await page.getByRole('button',{name:'Play',exact:true}).focus();await page.keyboard.press('Enter');
    await expect(page.getByRole('heading',{name:'Loading',exact:true})).toBeVisible();
    await arena(page);expect(Date.now()-start).toBeGreaterThanOrEqual(300);
    await expect(page.getByRole('heading',{name:'Static Arena',exact:true})).toBeFocused();
    const mounted=await counts(page);
    expect(mounted).toMatchObject({applications:1,resources:1,subscriptions:1,canvases:1,observers:2,resize:1,density:1,frames:0,cache:{leases:1,pending:false}});
    await expect(page.locator('.arena-host')).toHaveAttribute('data-ticker-started','false');
    await menu(page);await expect(page.getByRole('button',{name:'Play',exact:true})).toBeFocused();await settled(page);
    const unmounted=await counts(page);
    expect(unmounted).toMatchObject({applications:0,resources:0,subscriptions:0,canvases:0,observers:0,resize:0,density:0,frames:0,cache:{leases:0,pending:false}});
    expect(unmounted.cache.textures).toBeGreaterThan(0);cycles.push({cycle,mounted,unmounted});
  }
  await info.attach('resource-cycles',{body:JSON.stringify({initial,cycles},null,2),contentType:'application/json'});
});
test('fail-once before cold/warm cache and Retry without refresh',async({page},info)=>{
  await page.goto('/?assetScenario=fail-once');await page.getByRole('button',{name:'Play',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Loading failed'})).toBeVisible();expect((await counts(page)).cache.textures).toBe(0);
  await screenshot(page,info,'fail-once');await page.getByRole('button',{name:'Retry',exact:true}).click();await arena(page);await menu(page);
  await page.getByRole('button',{name:'Play',exact:true}).click();await arena(page);await menu(page);
  // A new page session first warms normally, then configures the documented URL in-place.
  await page.goto('/');await page.getByRole('button',{name:'Play',exact:true}).click();await arena(page);await menu(page);
  const warm=(await counts(page)).cache.textures;
  await page.evaluate(()=>history.replaceState(null,'','/?assetScenario=fail-once'));
  await page.getByRole('button',{name:'Play',exact:true}).click();await expect(page.getByRole('heading',{name:'Loading failed'})).toBeVisible();
  expect((await counts(page)).cache.textures).toBe(warm);expect((await counts(page)).cache.leases).toBe(0);
  await page.getByRole('button',{name:'Retry',exact:true}).click();await arena(page);expect((await counts(page)).cache.textures).toBe(warm);await menu(page);
});
test('Main Menu cancels a pending load and old callbacks cannot replace a new attempt',async({page})=>{
  let release!:()=>void;let requested!:()=>void;const requestStarted=new Promise<void>(resolve=>{requested=resolve;});const gate=new Promise<void>(resolve=>{release=resolve;});
  await page.route('**/*ship_5*.png*',async route=>{requested();await gate;await route.continue();});
  await page.goto('/');await page.getByRole('button',{name:'Play',exact:true}).click();await requestStarted;
  await expect(page.getByRole('heading',{name:'Loading',exact:true})).toBeVisible();await menu(page);
  expect((await counts(page)).cache.pending).toBe(true);expect((await counts(page)).cache.leases).toBe(0);
  release();await expect.poll(async()=> (await counts(page)).cache.pending).toBe(false);
  await expect(page.getByRole('button',{name:'Play',exact:true})).toBeVisible();await expect(page.locator('canvas')).toHaveCount(0);
  await page.getByRole('button',{name:'Play',exact:true}).click();await arena(page);await menu(page);
});
test('real asset failure retries and graphics init failure stays semantic',async({page},info)=>{
  let failing=true;
  await page.route('**/*ship_5*.png*',async route=>{if(failing)await route.fulfill({status:200,contentType:'image/png',body:'invalid image bytes'});else await route.continue();});
  await page.goto('/');await page.getByRole('button',{name:'Play',exact:true}).click();await expect(page.getByRole('heading',{name:'Loading failed'})).toBeVisible();
  await expect(page.locator('canvas')).toHaveCount(0);failing=false;await page.getByRole('button',{name:'Retry',exact:true}).click();await arena(page);await menu(page);
  await page.addInitScript(()=>{HTMLCanvasElement.prototype.getContext=(()=>null) as typeof HTMLCanvasElement.prototype.getContext;});
  await page.goto('/');await page.getByRole('button',{name:'Play',exact:true}).click();await expect(page.getByRole('heading',{name:'Loading failed'})).toBeVisible();
  await expect(page.getByRole('button',{name:'Retry',exact:true})).toBeVisible();await expect(page.locator('canvas')).toHaveCount(0);
  expect((await counts(page)).applications).toBe(0);expect((await counts(page)).cache.leases).toBe(0);
  await screenshot(page,info,'graphics-failure');await menu(page);
});
test('fits desktop/portrait/landscape and isolated DPR changes without rebuilding',async({page,context},info)=>{
  await page.goto('/?geometry=1');await page.getByRole('button',{name:'Play',exact:true}).click();await arena(page);
  const samples=[];
  for(const [label,width,height] of [['desktop',1280,900],['320x568',320,568],['390x844',390,844],['844x390',844,390]] as const) {
    await page.setViewportSize({width,height});await expect.poll(()=>page.locator('canvas').evaluate(c=>(c as HTMLCanvasElement).width)).toBe(width);
    const sample=await page.locator('.arena-host').evaluate(host=>({viewport:JSON.parse((host as HTMLElement).dataset.viewport!),player:JSON.parse((host as HTMLElement).dataset.player!),width:innerWidth,height:innerHeight,scrollWidth:document.documentElement.scrollWidth}));
    expect(sample.scrollWidth).toBe(width);const v=sample.viewport;expect(v.renderable).toBe(true);
    expect(v.offsetX).toBeGreaterThanOrEqual(-1e-8);expect(v.offsetY).toBeGreaterThanOrEqual(48-1e-8);
    expect(v.offsetX+960*v.scale).toBeLessThanOrEqual(width+1e-8);expect(v.offsetY+540*v.scale).toBeLessThanOrEqual(height-88+1e-8);
    expect(sample.player).toEqual({xUnits:480,yUnits:270,headingRadians:-Math.PI/2,width:33,height:56.5,rotation:-Math.PI});
    samples.push({label,...sample});await screenshot(page,info,label);
  }
  const before=await page.locator('.arena-host').getAttribute('data-viewport');
  const session=await context.newCDPSession(page);
  await session.send('Emulation.setDeviceMetricsOverride',{width:844,height:390,deviceScaleFactor:2,mobile:false});
  // CDP metrics updates DPR but Chromium defers media-query evaluation until media invalidation.
  // This emits the native resolution change; no application callback/resize is invoked.
  await session.send('Emulation.setEmulatedMedia',{media:'screen'});
  await expect.poll(()=>page.evaluate(()=>devicePixelRatio)).toBe(2);
  await expect.poll(()=>page.locator('canvas').evaluate(c=>(c as HTMLCanvasElement).width)).toBe(1688);
  expect(await page.locator('.arena-host').getAttribute('data-viewport')).toBe(before);expect((await counts(page)).canvases).toBe(1);
  const raw=await session.send('Page.captureScreenshot',{format:'png'});
  const dprFile=path.resolve(evidence,`${info.project.name}-844x390-dpr2.png`);await writeFile(dprFile,Buffer.from(raw.data,'base64'));await info.attach('844x390-dpr2',{path:dprFile,contentType:'image/png'});samples.push({label:'dpr2',buffer:await page.locator('canvas').evaluate(c=>[(c as HTMLCanvasElement).width,(c as HTMLCanvasElement).height]),dpr:await page.evaluate(()=>devicePixelRatio)});
  await session.send('Emulation.setDeviceMetricsOverride',{width:844,height:390,deviceScaleFactor:1,mobile:false});
  await session.send('Emulation.setEmulatedMedia',{media:'screen'});
  await expect.poll(()=>page.locator('canvas').evaluate(c=>(c as HTMLCanvasElement).width)).toBe(844);
  await info.attach('viewport-observations',{body:JSON.stringify(samples,null,2),contentType:'application/json'});
  // Use an actual touch event on the provided DOM action.
  const button=await page.getByRole('button',{name:'Main Menu',exact:true}).boundingBox();expect(button).not.toBeNull();await page.touchscreen.tap(button!.x+button!.width/2,button!.y+button!.height/2);
  await expect(page.getByRole('button',{name:'Play',exact:true})).toBeVisible();await expect(page.locator('canvas')).toHaveCount(0);
});
